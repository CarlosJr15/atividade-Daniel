<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Tabuada em PHP</title>
</head>
<body>
    <h2>Gerar Tabuada</h2>

    <!-- Formulário para enviar o número -->
    <form method="post">
        Digite um número: 
        <input type="number" name="numero" required>
        <button type="submit">Calcular</button>
    </form>

    <hr>

    <?php
    // Função que calcula a tabuada e salva no arquivo
    function gerarTabuada($num) {
        $arquivo = "tabuada.txt";
        $conteudo = "Tabuada do $num\n";

        // Calcula a tabuada de 1 até 10
        for ($i = 1; $i <= 10; $i++) {
            $linha = "$i x $num = " . ($i * $num) . "\n";
            $conteudo .= $linha;
        }

        // Salva no arquivo
        file_put_contents($arquivo, $conteudo);

        return $arquivo;
    }

    // Se o formulário foi enviado
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $numero = (int)$_POST["numero"];

        // Gera e salva no arquivo
        $arquivo = gerarTabuada($numero);

        echo "<h3>Tabuada de $numero salva em '$arquivo'</h3>";
        echo "<pre>" . file_get_contents($arquivo) . "</pre>";
    }
    ?>
</body>
</html>



