<?php
// Caminho do arquivo JSON
$arquivo = "usuarios.json";

// Recebe os dados do formulário
$nome = $_POST['nome'] ?? '';
$email = $_POST['email'] ?? '';

// Lê o conteúdo do arquivo JSON, se existir
$usuarios = [];
if (file_exists($arquivo)) {
    $conteudo = file_get_contents($arquivo);
    $usuarios = json_decode($conteudo, true);
    if (!is_array($usuarios)) {
        $usuarios = []; // garante que seja array
    }
}

// Adiciona o novo usuário ao array
if ($nome && $email) {
    $usuarios[] = [
        "nome" => $nome,
        "email" => $email
    ];
}

// Salva o array atualizado de volta no JSON
file_put_contents($arquivo, json_encode($usuarios, JSON_PRETTY_PRINT));

// Redireciona para a página que lista os usuários
header('Location: lista_usuarios.php');
exit;
