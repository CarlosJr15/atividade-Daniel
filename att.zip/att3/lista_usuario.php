<?php
$arquivo = "usuarios.json";

// Lê o conteúdo do arquivo JSON
$usuarios = [];
if (file_exists($arquivo)) {
    $conteudo = file_get_contents($arquivo);
    $usuarios = json_decode($conteudo, true);
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Usuários</title>
</head>
<body>
    <h2>Usuários Cadastrados</h2>

    <?php if (!empty($usuarios)): ?>
        <ul>
            <?php foreach ($usuarios as $usuario): ?>
                <li>
                    Nome: <?= htmlspecialchars($usuario['nome']) ?>,
                    E-mail: <?= htmlspecialchars($usuario['email']) ?>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>Nenhum usuário cadastrado ainda.</p>
    <?php endif; ?>

    <br>
    <a href="cadastro.php">Cadastrar novo usuário</a>
</body>
</html>
