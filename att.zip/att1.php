<?php
// Nome do arquivo
$arquivo = "frases.txt";

// Conteúdo a ser gravado
$frases = "Primeira frase.\n";
$frases .= "Segunda frase.\n";
$frases .= "Terceira frase.\n";

// Abre o arquivo no modo escrita ("w" sobrescreve se já existir)
$handle = fopen($arquivo, "w");

// Grava as frases
fwrite($handle, $frases);

// Fecha o arquivo
fclose($handle);

echo "Arquivo '$arquivo' criado com sucesso!";


$arquivo = "frases.txt";

// Verifica se o arquivo existe
if (file_exists($arquivo)) {
    // Lê todo o conteúdo do arquivo
    $conteudo = file_get_contents($arquivo);

    echo "<h3>Conteúdo do arquivo:</h3>";
    echo nl2br($conteudo); // nl2br() mantém as quebras de linha no HTML
} else {
    echo "O arquivo '$arquivo' não existe!";
}
?>
